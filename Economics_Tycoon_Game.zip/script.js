let capital = 10000;
let currentQuestionIndex = 0;

// AQA Economics questions (based on supply & demand, inflation, market structures)
const questions = [
    {
        question: "If the Bank of England raises interest rates, what is the likely impact on consumer spending?",
        options: ["Increase", "Decrease", "No Change"],
        correct: "Decrease",
        effect: -1000
    },
    {
        question: "What happens when the government imposes a price ceiling below equilibrium price?",
        options: ["Surplus", "Shortage", "No Effect"],
        correct: "Shortage",
        effect: 2000
    },
    {
        question: "If inflation rises, what happens to the real value of money?",
        options: ["Increases", "Decreases", "Stays the same"],
        correct: "Decreases",
        effect: -1500
    },
    {
        question: "Which market structure has many firms selling differentiated products?",
        options: ["Perfect Competition", "Oligopoly", "Monopolistic Competition"],
        correct: "Monopolistic Competition",
        effect: 3000
    }
];

function loadQuestion() {
    if (currentQuestionIndex >= questions.length) {
        document.getElementById("message").textContent = "You've completed the game!";
        document.getElementById("question-container").style.display = "none";
        document.getElementById("next-button").style.display = "none";
        return;
    }

    let questionObj = questions[currentQuestionIndex];
    document.getElementById("question").textContent = questionObj.question;
    
    let optionsDiv = document.getElementById("options");
    optionsDiv.innerHTML = "";
    
    questionObj.options.forEach(option => {
        let btn = document.createElement("button");
        btn.textContent = option;
        btn.onclick = () => checkAnswer(option, questionObj.correct, questionObj.effect);
        optionsDiv.appendChild(btn);
    });
}

function checkAnswer(selected, correct, effect) {
    let messageDiv = document.getElementById("message");
    
    if (selected === correct) {
        messageDiv.textContent = "Correct! Your business grows.";
        capital += effect;
    } else {
        messageDiv.textContent = "Incorrect! Your business loses money.";
        capital -= effect;
    }

    document.getElementById("capital").textContent = capital;
    currentQuestionIndex++;
}

function nextDecision() {
    loadQuestion();
}

loadQuestion();
